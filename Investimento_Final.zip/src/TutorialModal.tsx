import { useState } from 'react';
import {
  XCircle,
  Info,
  ArrowRightLeft,
  LineChart,
  Banknote,
  LockKeyhole,
  MoveRight,
  Calculator
} from 'lucide-react';

const passos = [
  {
    titulo: 'Login e Senha',
    icone: <LockKeyhole className="w-7 h-7 text-blue-600" />,
    texto: 'Você acessa com o nome do grupo e uma senha de 6 dígitos. Essa senha será usada para autorizar transações dentro da simulação.',
  },
  {
    titulo: 'Realizar Depósitos',
    icone: <Banknote className="w-7 h-7 text-green-600" />,
    texto: 'Você pode investir um valor inicial e escolher quanto alocar para Renda Fixa e Renda Variável. O sistema distribuirá automaticamente.',
  },
  {
    titulo: 'Adicionar Ativos',
    icone: <Info className="w-7 h-7 text-indigo-600" />,
    texto: 'Você poderá adicionar ativos reais como ações, FIIs, criptomoedas e títulos de renda fixa. O sistema calcula preços médios, rendimentos e IR.',
  },
  {
    titulo: 'Atualizar Valores',
    icone: <MoveRight className="w-7 h-7 text-yellow-600" />,
    texto: 'Use o botão “Atualizar valores” para buscar preços de mercado e atualizar seus ativos. Pode ser usado a cada 30 minutos.',
  },
  {
    titulo: 'Gráficos e Extrato',
    icone: <LineChart className="w-7 h-7 text-purple-600" />,
    texto: 'Visualize a evolução do patrimônio ao longo do tempo em gráficos. Use a aba de extrato para ver o histórico completo de ações.',
  },
  {
    titulo: 'Transferências e Dividendos',
    icone: <ArrowRightLeft className="w-7 h-7 text-pink-600" />,
    texto: 'Você pode transferir valores entre fixa e variável, ou informar dividendos recebidos nos FIIs (após o dia 15).',
  },
  {
    titulo: 'Imposto de Renda (IR)',
    icone: <Calculator className="w-7 h-7 text-red-600" />,
    texto: `📌 **Renda Fixa**:
- O IR é calculado automaticamente no momento do resgate.
- Alíquotas seguem a tabela regressiva da Receita Federal:
  - Até 180 dias: 22,5%
  - De 181 a 360 dias: 20%
  - De 361 a 720 dias: 17,5%
  - Acima de 720 dias: 15%
- O imposto é descontado do rendimento e o valor líquido vai para seu saldo.

📌 **Renda Variável (ações, FIIs e criptomoedas)**:
- Use o botão **“Informar Imposto de Renda”**.
- O sistema verifica **todas as vendas do mês** e calcula automaticamente o imposto sobre o lucro líquido:
  - Isenção se o total de vendas de ações for menor que R$ 20.000 no mês.
  - FIIs e criptomoedas são sempre tributáveis se houver lucro.
- O IR é registrado no histórico, e o valor do imposto é deduzido automaticamente do saldo de Renda Variável.
- Você pode usar esses dados diretamente na sua declaração (IRPF ou GCAP).`,
  }
];

interface Props {
  onClose: () => void;
}

export default function TutorialModal({ onClose }: Props) {
  const [etapa, setEtapa] = useState(0);
  const total = passos.length;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto p-10 relative">
        {/* Botão de fechar */}
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-500 hover:text-red-600 transition">
          <XCircle size={28} />
        </button>

        {/* Cabeçalho do passo */}
        <div className="flex items-center gap-4 mb-4">
          {passos[etapa].icone}
          <h2 className="text-2xl font-bold text-blue-800">{passos[etapa].titulo}</h2>
        </div>

        {/* Conteúdo do passo */}
        <p className="text-gray-700 text-lg leading-relaxed mb-8 whitespace-pre-line">{passos[etapa].texto}</p>

        {/* Navegação */}
        <div className="flex justify-between items-center mt-6">
          <button
            onClick={() => setEtapa((e) => Math.max(0, e - 1))}
            className="text-sm px-5 py-2 bg-gray-100 rounded hover:bg-gray-200"
            disabled={etapa === 0}
          >
            Voltar
          </button>

          <span className="text-sm text-gray-500">Etapa {etapa + 1} de {total}</span>

          {etapa < total - 1 ? (
            <button
              onClick={() => setEtapa((e) => Math.min(total - 1, e + 1))}
              className="text-sm px-5 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
            >
              Próximo
            </button>
          ) : (
            <button
              onClick={onClose}
              className="text-sm px-5 py-2 bg-green-600 text-white rounded hover:bg-green-700"
            >
              Ir para Simulação
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
