export  interface ResumoIR {
  mes: string;
  subtipo: string;
  valorVenda: number;
  valorCompra: number;
  imposto: number;
}