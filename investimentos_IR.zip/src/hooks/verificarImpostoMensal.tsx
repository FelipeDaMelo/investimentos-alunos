import { doc, updateDoc, arrayUnion } from 'firebase/firestore';
import { db } from '../firebaseConfig';
import { Dispatch, SetStateAction } from 'react';
import { RegistroHistorico } from './RegistroHistorico';
import { ResumoIR } from '../components/ResumoIR';
import { calcularImpostoRenda } from './useCalcularIR';

interface CompraFIFO {
  nome: string;
  subtipo: 'acao' | 'fii' | 'criptomoeda';
  data: string;
  quantidade: number;
  valorTotal: number;
}

export async function verificarImpostoMensal(
  historico: RegistroHistorico[],
  setValorVariavelDisponivel: Dispatch<SetStateAction<number>>,
  setHistorico: Dispatch<SetStateAction<RegistroHistorico[]>>,
  login: string,
  somenteResumo: boolean
): Promise<ResumoIR[]> {
  const hoje = new Date();
  const comprasFIFO = new Map<string, CompraFIFO[]>();
  const vendasPorMes = new Map<string, { valorVenda: number; valorCompra: number; subtipo: string }>();

  historico.forEach(registro => {
    if (!registro.nome || !registro.subtipo || !registro.quantidade) return;

    const chaveAtivo = `${registro.subtipo}-${registro.nome}`;
    const mes = registro.data.slice(0, 7); // YYYY-MM

    if (registro.tipo === 'compra') {
      const lista = comprasFIFO.get(chaveAtivo) || [];
      lista.push({
        nome: registro.nome,
        subtipo: registro.subtipo,
        data: registro.data,
        quantidade: registro.quantidade,
        valorTotal: registro.valor,
      });
      comprasFIFO.set(chaveAtivo, lista);
    }

    if (registro.tipo === 'venda') {
      let qtdRestante = registro.quantidade;
      let custoTotal = 0;
      const lista = comprasFIFO.get(chaveAtivo) || [];

      while (qtdRestante > 0 && lista.length > 0) {
        const compra = lista[0];
        const qtdConsumir = Math.min(qtdRestante, compra.quantidade);
        const precoUnit = compra.valorTotal / compra.quantidade;
        custoTotal += qtdConsumir * precoUnit;
        compra.quantidade -= qtdConsumir;
        qtdRestante -= qtdConsumir;
        if (compra.quantidade === 0) lista.shift();
      }

      const chaveMes = `${registro.subtipo}-${mes}`;
      const atual = vendasPorMes.get(chaveMes) || {
        valorVenda: 0,
        valorCompra: 0,
        subtipo: registro.subtipo,
      };

      const valorVenda = registro.valorBruto ?? registro.valor;
      vendasPorMes.set(chaveMes, {
        subtipo: registro.subtipo,
        valorVenda: atual.valorVenda + valorVenda,
        valorCompra: atual.valorCompra + custoTotal,
      });
    }
  });

  const resumos: ResumoIR[] = [];

  for (const [chave, dados] of vendasPorMes.entries()) {
    const [subtipoChave, ...resto] = chave.split('-');
    const mesAno = resto.join('-'); // garante YYYY-MM mesmo com split múltiplo

    const imposto = calcularImpostoRenda({
      subtipo: subtipoChave as 'acao' | 'fii' | 'criptomoeda',
      data: `${mesAno}-01`,
      valorVenda: dados.valorVenda,
      valorCompra: dados.valorCompra,
      totalVendidoNoMes: dados.valorVenda,
    });

    resumos.push({
      mes: mesAno,
      subtipo: subtipoChave,
      valorVenda: dados.valorVenda,
      valorCompra: dados.valorCompra,
      imposto
    });

    if (!somenteResumo && imposto > 0 && mesEncerrado(mesAno, hoje)) {
      setValorVariavelDisponivel(prev => prev - imposto);

      const registroIR: RegistroHistorico = {
        tipo: 'ir',
        valor: imposto,
        categoria: 'rendaVariavel',
        subtipo: subtipoChave as 'acao' | 'fii' | 'criptomoeda',
        data: `${mesAno}-01`
      };

      setHistorico(prev => [...prev, registroIR]);

      const docRef = doc(db, 'usuarios', login);
      await updateDoc(docRef, {
        historico: arrayUnion(registroIR)
      });
    }
  }

  return resumos;
}

function mesEncerrado(mesAno: string, hoje: Date): boolean {
  const [ano, mes] = mesAno.split('-').map(Number);
  const dataLimite = new Date(ano, mes, 1); // primeiro dia do próximo mês
  return hoje >= dataLimite || hoje.getDate() > 25;
}
